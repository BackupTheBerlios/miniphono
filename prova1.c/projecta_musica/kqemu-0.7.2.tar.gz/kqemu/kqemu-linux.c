/*
 * Linux kernel wrapper for KQEMU
 * Copyright (c) 2004-2005 Fabrice Bellard
 */
#include <linux/module.h>
#include <linux/types.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/mm.h>
#include <linux/proc_fs.h>
#include <linux/version.h>
#include <linux/ioctl.h>
#include <linux/smp_lock.h>
#include <linux/miscdevice.h>
#include <asm/atomic.h>
#include <asm/processor.h>
#include <asm/uaccess.h>
#include <asm/io.h>

#include "kqemu-kernel.h"

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,19)
#error "Linux 2.4.19 or above needed"
#endif

#ifndef page_to_pfn
#define page_to_pfn(page) ((page) - mem_map)
#define pfn_to_page(pfn) (mem_map + (pfn))
#endif

#ifdef PAGE_KERNEL_EXEC
#if defined(__i386__)
/* problem : i386 kernels usually don't export __PAGE_KERNEL_EXEC */
#undef PAGE_KERNEL_EXEC
#define PAGE_KERNEL_EXEC __pgprot(__PAGE_KERNEL & ~_PAGE_NX)
#endif
#else
#define PAGE_KERNEL_EXEC PAGE_KERNEL
#endif

//#define DEBUG

#ifdef DEBUG
int lock_count;
int page_alloc_count;
#endif

/* if 0 is used, then devfs/udev is used to automatically create the
   device */
int major = 250;
MODULE_PARM(major,"i");

/* configurable max_instances */
int max_instances = 4;
MODULE_PARM(max_instances,"i");

/* lock the page at virtual address 'user_addr' and return its
   page index. Return -1 if error */
struct kqemu_user_page *CDECL kqemu_lock_user_page(unsigned long *ppage_index,
                                                   unsigned long user_addr)
{
    int ret;
    struct page *page;

    ret = get_user_pages(current, current->mm,
                         user_addr,
                         1, /* 1 page. */
                         1, /* 'write': intent to write. */
                         0, /* 'force': ? */
                         &page,
                         NULL);
    if (ret != 1)
        return NULL;
    /* we ensure here that the page cannot be swapped out by the
       kernel. */
    /* XXX: This test may be incorrect for 2.6 kernels */
    if (!page->mapping) {
        put_page(page);
        return NULL;
    }
#ifdef DEBUG
    lock_count++;
#endif
    *ppage_index = page_to_pfn(page);
    return (struct kqemu_user_page *)page;
}

void CDECL kqemu_unlock_user_page(struct kqemu_user_page *page1)
{
    struct page *page = (struct page *)page1;
    set_page_dirty(page);
    put_page(page);
#ifdef DEBUG
    lock_count--;
#endif
}

/* Allocate a new page. The page must be mapped in the kernel
   space. Return the page_index or -1 if error */
struct kqemu_page *CDECL kqemu_alloc_zeroed_page(unsigned long *ppage_index)
{
    unsigned long vaddr;
    struct page *page;

    vaddr = get_zeroed_page(GFP_KERNEL);
    if (!vaddr)
        return NULL;
#ifdef DEBUG
    page_alloc_count++;
#endif
    page = virt_to_page(vaddr);
    *ppage_index = page_to_pfn(page);
    return (struct kqemu_page *)page;
}

void CDECL kqemu_free_page(struct kqemu_page *page1)
{
    struct page *page = (struct page *)page1;
    __free_page(page);
#ifdef DEBUG
    page_alloc_count--;
#endif
}

/* return a kernel address of the physical page page_index */
void * CDECL kqemu_page_kaddr(struct kqemu_page *page1)
{
    struct page *page = (struct page *)page1;
    return page_address(page);
}

/* contraint: each page of the vmalloced area must be in the first 4
   GB of physical memory. Moreover, execution of code should be
   enabled in the allocated area. */
void * CDECL kqemu_vmalloc(unsigned int size)
{
    return __vmalloc(size, GFP_KERNEL, PAGE_KERNEL_EXEC);
}

void CDECL kqemu_vfree(void *ptr)
{
    return vfree(ptr);
}

unsigned long CDECL kqemu_vmalloc_to_phys(const void *vaddr)
{
    struct page *page;
    page = vmalloc_to_page((void *)vaddr);
    if (!page)
        return -1;
    return page_to_pfn(page);
}

/* Map a IO area in the kernel address space and return its
   address. Return NULL if error or not implemented.  */
void * CDECL kqemu_io_map(unsigned long page_index, unsigned int size)
{
    return ioremap(page_index << PAGE_SHIFT, size);
}

/* Unmap the IO area */
void CDECL kqemu_io_unmap(void *ptr, unsigned int size)
{
    return iounmap(ptr);
}

/* return TRUE if a signal is pending (i.e. the guest must stop
   execution) */
int CDECL kqemu_schedule(void)
{
    if (need_resched()) {
        schedule();
    }
    return signal_pending(current);
}

char log_buf[4096];

void CDECL kqemu_log(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(log_buf, sizeof(log_buf), fmt, ap);
    printk("kqemu: %s", log_buf);
    va_end(ap);
}

/*********************************************************/

static int kqemu_nb_instances = 0;
static spinlock_t kqemu_lock = SPIN_LOCK_UNLOCKED;
static int max_locked_pages;

struct kqemu_instance {
    struct semaphore sem; 
    struct kqemu_state *state;
};

static int kqemu_open(struct inode *inode, struct file *filp)
{
    struct kqemu_instance *ks;
    
    spin_lock(&kqemu_lock);
    if (kqemu_nb_instances >= max_instances) {
        spin_unlock(&kqemu_lock);
        return -ENOMEM;
    }
    kqemu_nb_instances++;
    spin_unlock(&kqemu_lock);
    
    ks = kmalloc(sizeof(struct kqemu_instance), GFP_KERNEL);
    if (!ks)
        return -ENOMEM;
    init_MUTEX(&ks->sem);
    ks->state = NULL;
    filp->private_data = ks;
    return 0;
}

static int kqemu_release(struct inode *inode, struct file *filp)
{
    struct kqemu_instance *ks = filp->private_data;

    down(&ks->sem);
    if (ks->state) {
        kqemu_delete(ks->state);
        ks->state = NULL;
    }
    up(&ks->sem);

    kfree(ks);

    spin_lock(&kqemu_lock);
    kqemu_nb_instances--;
    spin_unlock(&kqemu_lock);

#ifdef DEBUG
    printk("lock_count=%d page_alloc_count=%d\n",
           lock_count, page_alloc_count);
#endif
    return 0;
}

static int kqemu_ioctl(struct inode *inode, struct file *filp,
                       unsigned int cmd, unsigned long arg)
{
    struct kqemu_instance *ks = filp->private_data;
    struct kqemu_state *s = ks->state;
    long ret;

    down(&ks->sem);
    switch(cmd) {
    case KQEMU_INIT:
        {
            struct kqemu_init d1, *d = &d1;
            if (s) {
                ret = -EIO;
                break;
            }
            if (copy_from_user(d, (void *)arg, sizeof(*d))) {
                ret = -EFAULT;
                break;
            }
            s = kqemu_init(d, max_locked_pages);
            if (!s) {
                ret = -ENOMEM;
                break;
            }
            ks->state = s;
            ret = 0;
        }
        break;
    case KQEMU_EXEC:
        {
            struct kqemu_cpu_state *ctx;
            if (!s) {
                ret = -EIO;
                break;
            }
            
            ctx = kqemu_get_cpu_state(s);
            if (copy_from_user(ctx, (void *)arg, sizeof(*ctx))) {
                ret = -EFAULT;
                break;
            }
            unlock_kernel();
            ret = kqemu_exec(s);
            lock_kernel();
            if (copy_to_user((void *)arg, ctx, sizeof(*ctx))) {
                ret = -EFAULT;
                break;
            }
        }
        break;
    case KQEMU_GET_VERSION:
        {
            if (put_user(KQEMU_VERSION, (int *)arg) < 0) {
                ret = -EFAULT;
            } else {
                ret = 0;
            }
        }
        break;
    default:
        ret = -ENOIOCTLCMD;
        break;
    }
    up(&ks->sem);
    return ret;
}

static struct file_operations kqemu_fops = {
    owner:    THIS_MODULE,
    ioctl:    kqemu_ioctl,
    open:     kqemu_open,
    release:  kqemu_release,
};

static struct miscdevice kqemu_dev =
{
    .minor      = MISC_DYNAMIC_MINOR,
    .name       = "kqemu",
    .fops       = &kqemu_fops,
};

int init_module(void)
{
    int ret;
    struct sysinfo si;

    printk("QEMU Accelerator Module version %d.%d.%d, Copyright (c) 2005 Fabrice Bellard\n"
           "This is a proprietary product. Read the LICENSE file for more information\n"
           "Redistribution of this module is prohibited without authorization\n",
           (KQEMU_VERSION >> 16),
           (KQEMU_VERSION >> 8) & 0xff,
           (KQEMU_VERSION) & 0xff);
    si_meminfo(&si);
    max_locked_pages = si.totalram / (2 * max_instances);
    if (max_locked_pages > 32768)
        max_locked_pages = 32768;

    if (major > 0) {
        ret = register_chrdev(major, "kqemu", &kqemu_fops);
        if (ret < 0) {
            printk("kqemu: could not get major %d\n", major);
            return ret;
        }
    } else {
        ret = misc_register (&kqemu_dev);
        if (ret < 0) {
            printk("kqemu: could not create device\n");
            return ret;
        }
    }
    printk("KQEMU installed, max_instances=%d max_locked_mem=%dkB.\n",
           max_instances, 
           max_locked_pages * 4);
    return 0;
}

void cleanup_module(void)
{
    if (major > 0) 
        unregister_chrdev(major, "kqemu");
    else
        misc_deregister (&kqemu_dev);
}
